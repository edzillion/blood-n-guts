export const MODULE_ID = 'blood-n-guts';
export const MODULE_TITLE = "Blood 'n Guts";
