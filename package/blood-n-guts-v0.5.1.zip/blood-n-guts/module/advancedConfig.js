var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { log, LogLevel } from "./logging.js";
import { MODULE_ID } from "../constants.js";
import * as violenceLevelSettings from "../data/violenceLevelSettings.js";
import * as splatFonts from "../data/splatFonts.js";
import { BloodNGuts } from "../blood-n-guts.js";
/**
 * FormApplication window for advanced configuration options.
 * @class
 * @extends FormApplication
 */
export class AdvancedConfig extends FormApplication {
    constructor(object, options) {
        super(object, options);
        game.settings.sheet.close();
        game.users.apps.push(this);
    }
    static get defaultOptions() {
        const options = super.defaultOptions;
        options.title = 'Configure Blood n Guts Advanced Settings';
        options.id = MODULE_ID;
        options.template = 'modules/blood-n-guts/templates/advanced-config.html';
        options.closeOnSubmit = true;
        options.popOut = true;
        options.width = 600;
        options.height = 'auto';
        return options;
    }
    getData() {
        return __awaiter(this, void 0, void 0, function* () {
            // todo: sort out this permissions stuff
            // const canConfigure = game.user.can('SETTINGS_MODIFY');
            const dataObject = {};
            const level = game.settings.get(MODULE_ID, 'violenceLevel');
            const violenceLevel = violenceLevelSettings.level[level];
            for (const key in violenceLevel) {
                dataObject[key] = game.settings.get(MODULE_ID, key);
            }
            dataObject['fonts'] = splatFonts.fonts;
            dataObject['floorSplatFont'] = game.settings.get(MODULE_ID, 'floorSplatFont');
            dataObject['tokenSplatFont'] = game.settings.get(MODULE_ID, 'tokenSplatFont');
            dataObject['trailSplatFont'] = game.settings.get(MODULE_ID, 'trailSplatFont');
            return dataObject;
        });
    }
    render(force, context = {}) {
        return super.render(force, context);
    }
    activateListeners(html) {
        super.activateListeners(html);
        const wipeButton = html.find('.advanced-config-wipe-scene-splats');
        if (canvas.scene.active) {
            wipeButton.click(() => {
                log(LogLevel.DEBUG, 'wipeButton: BloodNGuts.wipeSceneSplats()');
                BloodNGuts.wipeSceneSplats();
                this.close();
            });
        }
        else
            wipeButton.attr('disabled', true);
    }
    _updateObject(event, formData) {
        return __awaiter(this, void 0, void 0, function* () {
            for (const setting in formData) {
                game.settings.set(MODULE_ID, setting, formData[setting]);
            }
        });
    }
}
