/**
 * Documentation for Blood 'n Guts, a Foundry VTT module that adds blood splatter to your games.
 * All functionality is wrapped in it's main Class `BloodNGuts`.
 * @license [GNU GPLv3.0 & 'Commons Clause' License Condition v1.0]{@link https://github.com/edzillion/blood-n-guts/blob/master/LICENSE.md}
 * @packageDocumentation
 * @author [edzillion]{@link https://github.com/edzillion}
 */
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { registerSettings } from "./module/settings.js";
import { preloadTemplates } from "./module/preloadTemplates.js";
import { log, LogLevel } from "./module/logging.js";
import { getRandomGlyph, lookupTokenBloodColor, computeSightFromPoint, drawDebugRect, getRandomBoxMuller, getDirectionNrml, alignSplatsGetOffsetAndDimensions, getPointOnCurve, getUID, } from "./module/helpers.js";
import * as splatFonts from "./data/splatFonts.js";
import { MODULE_ID } from "./constants.js";
globalThis.sceneSplatPool = [];
//CONFIG.debug.hooks = true;
CONFIG.bng = { logLevel: 2 };
let ourchild;
/**
 * Main class wrapper for all blood-n-guts features.
 * @class
 */
export class BloodNGuts {
    static initialize() {
        BloodNGuts.allFontsLoaded = false;
        BloodNGuts.splatState = [];
        BloodNGuts.tokenState = [];
        BloodNGuts.splatTokens = {};
    }
    /**
     * Generate splats on the floor beneath a token.
     * @category GMOnly
     * @function
     * @param {Token} token - the token to generate splats for.
     * @param {SplatFont} font - the font to use for splats.
     * @param {number} size - the size of splats.
     * @param {number} density - the amount of splats.
     * @param {number} severity - more and bigger splats based on the severity of the wound.
     */
    static splatFloor(splatToken, font, size, density) {
        if (!density)
            return;
        log(LogLevel.INFO, 'generateFloorSplats');
        const splatStateObj = {};
        // scale the splats based on token size and severity
        const fontSize = Math.round(size * ((splatToken.w + splatToken.h) / canvas.grid.size / 2) * severity);
        log(LogLevel.DEBUG, 'generateFloorSplats fontSize', fontSize);
        splatStateObj.styleData = {
            fontFamily: font.name,
            fontSize: fontSize,
            fill: splatToken.bloodColor,
            align: 'center',
        };
        const style = new PIXI.TextStyle(splatStateObj.styleData);
        // amount of splats is based on density and severity
        const amount = Math.round(density * splatToken.hitSeverity);
        // get a random glyph and then get a random (x,y) spread away from the token.
        const glyphArray = Array.from({ length: amount }, () => getRandomGlyph(font));
        const pixelSpreadX = splatToken.w * game.settings.get(MODULE_ID, 'splatSpread');
        const pixelSpreadY = splatToken.h * game.settings.get(MODULE_ID, 'splatSpread');
        log(LogLevel.DEBUG, 'generateFloorSplats amount', amount);
        log(LogLevel.DEBUG, 'generateFloorSplats pixelSpread', pixelSpreadX, pixelSpreadY);
        // create our splats for later drawing.
        splatStateObj.splats = glyphArray.map((glyph) => {
            const tm = PIXI.TextMetrics.measureText(glyph, style);
            const randX = getRandomBoxMuller() * pixelSpreadX - pixelSpreadX / 2;
            const randY = getRandomBoxMuller() * pixelSpreadY - pixelSpreadY / 2;
            return {
                x: Math.round(randX - tm.width / 2),
                y: Math.round(randY - tm.height / 2),
                width: tm.width,
                height: tm.height,
                glyph: glyph,
            };
        });
        const { offset, width, height } = alignSplatsGetOffsetAndDimensions(splatStateObj.splats);
        splatStateObj.offset = offset;
        splatStateObj.x = offset.x;
        splatStateObj.y = offset.y;
        const maxDistance = Math.max(width, height);
        const sight = computeSightFromPoint(splatToken.token.center, maxDistance);
        // since we don't want to add the mask to the splatsContainer yet (as that will
        // screw up our alignment) we need to move it by editing the x,y points directly
        for (let i = 0; i < sight.length; i += 2) {
            sight[i] -= splatStateObj.offset.x;
            sight[i + 1] -= splatStateObj.offset.y;
        }
        splatStateObj.x += splatToken.token.center.x;
        splatStateObj.y += splatToken.token.center.y;
        splatStateObj.maskPolygon = sight;
        return BloodNGuts.saveToSceneFlag([splatStateObj]);
    }
    /**
     * Generate splats on the token itself.
     * @category GMOnly
     * @function
     * @param {Token} token - the token to generate splats for.
     * @param {SplatFont} font - the font to use for splats.
     * @param {number} size - the size of splats.
     * @param {number} density - the amount of splats.
     * @param {number} severity - more and bigger splats based on the severity of the wound.
     */
    static splatToken(token, font, size, density, severity) {
        if (!density)
            return;
        log(LogLevel.INFO, 'generateTokenSplats');
        const splatStateObj = {};
        // scale the splats based on token size and severity
        const fontSize = Math.round(size * ((token.w + token.h) / canvas.grid.size / 2) * severity);
        log(LogLevel.DEBUG, 'generateTokenSplats fontSize', fontSize);
        splatStateObj.styleData = {
            fontFamily: font.name,
            fontSize: fontSize,
            fill: lookupTokenBloodColor(token),
            align: 'center',
        };
        const style = new PIXI.TextStyle(splatStateObj.styleData);
        splatStateObj.tokenId = token.id;
        // amount of splats is based on density and severity
        const amount = Math.round(density * severity);
        if (amount === 0)
            return;
        // get a random glyph and then get a random (x,y) spread away from the token.
        const glyphArray = Array.from({ length: amount }, () => getRandomGlyph(font));
        const pixelSpreadX = token.w * game.settings.get(MODULE_ID, 'splatSpread');
        const pixelSpreadY = token.h * game.settings.get(MODULE_ID, 'splatSpread');
        log(LogLevel.DEBUG, 'generateTokenSplats amount', amount);
        log(LogLevel.DEBUG, 'generateTokenSplats pixelSpread', pixelSpreadX, pixelSpreadY);
        // create our splats for later drawing.
        splatStateObj.splats = glyphArray.map((glyph) => {
            const tm = PIXI.TextMetrics.measureText(glyph, style);
            const randX = getRandomBoxMuller() * pixelSpreadX - pixelSpreadX / 2;
            const randY = getRandomBoxMuller() * pixelSpreadY - pixelSpreadY / 2;
            return {
                x: Math.round(randX - tm.width / 2),
                y: Math.round(randY - tm.height / 2),
                width: tm.width,
                height: tm.height,
                glyph: glyph,
            };
        });
        const { offset } = alignSplatsGetOffsetAndDimensions(splatStateObj.splats);
        splatStateObj.offset = offset;
        splatStateObj.x = offset.x + token.w / 2;
        splatStateObj.y = offset.y + token.h / 2;
        return splatStateObj;
    }
    /**
     * Generate splats in a trail on the floor behind a moving token.
     * @category GMOnly
     * @function
     * @param {Token} token - the token to generate splats for.
     * @param {SplatFont} font - the font to use for splats.
     * @param {number} size - the size of splats.
     * @param {number} density - the amount of splats.
     * @param {number} severity - more and bigger splats based on the severity of the wound.
     */
    static splatTrail(splatToken, font, size, density) {
        if (!density)
            return;
        log(LogLevel.INFO, 'generateTrailSplats');
        log(LogLevel.DEBUG, 'generateTrailSplats severity', splatToken.bleedingSeverity);
        const splatStateObj = {};
        // scale the splats based on token size and severity
        const fontSize = Math.round(size * ((splatToken.w + splatToken.h) / canvas.grid.size / 2) * splatToken.bleedingSeverity);
        log(LogLevel.DEBUG, 'generateTokenSplats fontSize', fontSize);
        splatStateObj.styleData = {
            fontFamily: font.name,
            fontSize: fontSize,
            fill: splatToken.bloodColor,
            align: 'center',
        };
        const style = new PIXI.TextStyle(splatStateObj.styleData);
        const origin = new PIXI.Point(0);
        const trailOrigin = new PIXI.Point(splatToken.direction.x * canvas.grid.size, splatToken.direction.y * canvas.grid.size);
        log(LogLevel.DEBUG, 'generateTokenSplats origin,trailOrigin', origin, trailOrigin);
        //horiz or vert movement
        const pixelSpread = splatToken.direction.x
            ? splatToken.w * game.settings.get(MODULE_ID, 'splatSpread') * 2
            : splatToken.h * game.settings.get(MODULE_ID, 'splatSpread') * 2;
        const rand = getRandomBoxMuller() * pixelSpread - pixelSpread / 2;
        log(LogLevel.DEBUG, 'generateTrailSplats rand', rand);
        // first go half the distance in the direction we are going
        const controlPt = new PIXI.Point(trailOrigin.x + splatToken.direction.x * (canvas.grid.size / 2), trailOrigin.y + splatToken.direction.y * (canvas.grid.size / 2));
        // then swap direction y,x to give us an position to the side
        controlPt.set(controlPt.x + splatToken.direction.y * rand, controlPt.y + splatToken.direction.x * rand);
        log(LogLevel.DEBUG, 'generateTrailSplats spread, ctrlPt', rand, controlPt);
        // get random glyphs and the interval between each splat
        // amount is based on density and severity
        const amount = Math.round(density * splatToken.bleedingSeverity);
        const glyphArray = Array.from({ length: amount }, () => getRandomGlyph(font));
        const increment = 1 / amount;
        log(LogLevel.DEBUG, 'generateTrailSplats amount', amount);
        // we skip 0 because that position already has a splat from the last trailSplat/floorSplat
        let dist = increment;
        // create our splats for later drawing.
        splatStateObj.splats = glyphArray.map((glyph) => {
            const tm = PIXI.TextMetrics.measureText(glyph, style);
            const pt = getPointOnCurve(trailOrigin, controlPt, origin, dist);
            dist += increment;
            return {
                x: Math.round(pt.x - tm.width / 2),
                y: Math.round(pt.y - tm.height / 2),
                width: tm.width,
                height: tm.height,
                glyph: glyph,
            };
        });
        log(LogLevel.DEBUG, 'generateTrailSplats splatStateObj.splats', splatStateObj.splats);
        const { offset, width, height } = alignSplatsGetOffsetAndDimensions(splatStateObj.splats);
        splatStateObj.offset = offset;
        splatStateObj.x = offset.x;
        splatStateObj.y = offset.y;
        const maxDistance = Math.max(width, height);
        const sight = computeSightFromPoint(splatToken.token.center, maxDistance);
        splatStateObj.maskPolygon = sight;
        // since we don't want to add the mask to the splatsContainer yet (as that will
        // screw up our alignment) we need to move it by editing the x,y points directly
        for (let i = 0; i < sight.length; i += 2) {
            sight[i] -= splatStateObj.offset.x;
            sight[i + 1] -= splatStateObj.offset.y;
        }
        splatStateObj.x += splatToken.token.center.x;
        splatStateObj.y += splatToken.token.center.y;
        return BloodNGuts.saveToSceneFlag([splatStateObj]);
    }
    /**
     * Draw splats to the canvas from it's state object and return a reference to the `PIXI.Container` that holds them.
     * @category GMOnly
     * @function
     * @param {SplatStateObject} splatStateObject - the splats data.
     * @returns {PIXI.Container} - the canvas reference.
     */
    static drawSplatsGetContainer(splatStateObject) {
        log(LogLevel.INFO, 'drawSplats');
        log(LogLevel.DEBUG, 'drawSplats: splatStateObject', splatStateObject);
        const splatsContainer = new PIXI.Container();
        const style = new PIXI.TextStyle(splatStateObject.styleData);
        // if it's maskPolygon type we can create a sightMask directly.
        if (splatStateObject.maskPolygon) {
            splatStateObject.splats.forEach((splat) => {
                const text = new PIXI.Text(splat.glyph, style);
                text.x = splat.x;
                text.y = splat.y;
                splatsContainer.addChild(text);
                return text;
            });
            log(LogLevel.DEBUG, 'drawSplats: splatStateObj.maskPolygon');
            const sightMask = new PIXI.Graphics();
            sightMask.beginFill(1, 1);
            sightMask.drawPolygon(splatStateObject.maskPolygon);
            sightMask.endFill();
            splatsContainer.addChild(sightMask);
            splatsContainer.mask = sightMask;
            splatsContainer.x = splatStateObject.x;
            splatsContainer.y = splatStateObject.y;
            canvas.tiles.addChild(splatsContainer);
        }
        // if it's tokenId add to our previously created tokenSplat container
        else if (splatStateObject.tokenId) {
            log(LogLevel.DEBUG, 'drawSplats: splatStateObj.tokenId');
            const splatToken = BloodNGuts.splatTokens[splatStateObject.tokenId];
            if (!splatToken)
                log(LogLevel.ERROR, 'drawSplats token not found!', splatStateObject);
            splatStateObject.splats.forEach((splat) => {
                const text = new PIXI.Text(splat.glyph, style);
                text.x = splat.x + splatStateObject.offset.x + splatToken.w / 2;
                text.y = splat.y + splatStateObject.offset.y + splatToken.h / 2;
                splatToken.splatsContainer.addChild(text);
                return text;
            });
            //todo: maybe don't need this
            // splatsContainer.pivot.set(tokenSpriteWidth / 2, tokenSpriteHeight / 2);
            // splatsContainer.position.set(token.w / 2, token.h / 2);
            // splatsContainer.angle = token.data.rotation;
        }
        else
            log(LogLevel.ERROR, 'drawSplats: splatStateObject should have either .imgPath or .maskPolygon!');
        if (CONFIG.bng.logLevel > LogLevel.DEBUG)
            drawDebugRect(splatsContainer);
        return splatsContainer;
    }
    /**
     * Saves the state of the token for later comparison.
     * @category GMOnly
     * @function
     * @param {Token} token - token to save.
     * @param {number} [severity=1] - severity of wound, scales trail splats. If set to 0 severity will be reset to 1.
     */
    static saveTokenState(token, severity = 1, splatsContainerZIndex) {
        log(LogLevel.INFO, 'saveTokenState:', token.data.name, token.id);
        BloodNGuts.splatTokens[token.id].saveState(token.data, severity);
    }
    /**
     * Saves the given `SplatStateObject` to our scene flag, add it's `.id` property if not already set.
     * @category GMOnly
     * @function
     * @param {Array<SplatStateObject>} [splatStateObj] - token data to save. if ommitted will just save the current
     * splatState (useful for removing stateObjs).
     */
    static saveToSceneFlag(newStateObjs) {
        if (!game.user.isGM)
            return;
        log(LogLevel.INFO, 'saveToSceneFlag', newStateObjs);
        const poolSize = game.settings.get(MODULE_ID, 'sceneSplatPoolSize');
        // add new state objs to the list and give them uids
        if (newStateObjs) {
            newStateObjs.forEach((s) => {
                if (!s.id)
                    s.id = getUID();
                BloodNGuts.splatState.push(s);
            });
            if (BloodNGuts.splatState.length > poolSize) {
                BloodNGuts.splatState.splice(0, BloodNGuts.splatState.length - poolSize);
            }
            log(LogLevel.DEBUG, `saveToSceneFlag splatState.length:${BloodNGuts.splatState.length}`);
        }
        log(LogLevel.DEBUG, 'saveToSceneFlag: stateObjects', BloodNGuts.splatState);
        return canvas.scene.setFlag(MODULE_ID, 'splatState', BloodNGuts.splatState);
    }
    /**
     * Adds the token data and a reference to the token on the canvas to our pool. The pool is a FIFO stack with
     * maximum size `blood-n-guts.sceneSplatPoolSize`. When size is exceeded the oldest entries are destroyed.
     * 15% of the oldest splats are set to fade (alpha 0.3) and the oldest 1/3 of those are set to very faded (alpha 0.1)
     * @category GMOnly
     * @function
     * @param {SplatStateObject} splatStateObj - token data to add.
     */
    static addToSplatPool(splatStateObj, splatsContainer = null) {
        log(LogLevel.INFO, 'addToSplatPool', splatStateObj);
        // if we set splatsContainer to null, it will be added on sceneUpdate when it is drawn to canvas.
        const poolObj = { state: splatStateObj, splatsContainer: splatsContainer };
        const maxPoolSize = game.settings.get(MODULE_ID, 'sceneSplatPoolSize');
        const fadedPoolSize = Math.floor(globalThis.sceneSplatPool.length * 0.15);
        const veryFadedPoolSize = Math.ceil(fadedPoolSize * 0.33);
        log(LogLevel.DEBUG, 'addToSplatPool sizes curr, max', globalThis.sceneSplatPool.length, maxPoolSize);
        if (globalThis.sceneSplatPool.length >= maxPoolSize) {
            // remove the oldest splat
            const destroy = globalThis.sceneSplatPool.shift();
            log(LogLevel.DEBUG, 'fadingSplatPool destroying id', destroy.state.id);
            destroy.splatsContainer.destroy({ children: true });
        }
        //add the new splat
        globalThis.sceneSplatPool.push(poolObj);
        // 15% of splats will be set to fade. 1/3rd of those will be very faded
        if (globalThis.sceneSplatPool.length >= fadedPoolSize) {
            const size = Math.min(fadedPoolSize, globalThis.sceneSplatPool.length);
            for (let index = 0; index < size; index++) {
                const alpha = index < veryFadedPoolSize ? 0.1 : 0.3;
                globalThis.sceneSplatPool[index].splatsContainer.alpha = alpha;
            }
        }
        log(LogLevel.DEBUG, `addToSplatPool sceneSplatPool:${globalThis.sceneSplatPool.length}, fadedPoolSize:${fadedPoolSize}, veryFadedPoolSize:${veryFadedPoolSize}`);
    }
    /**
     * Loads all `SplatStateObject`s from scene flag `splatState` and draws them - this
     * will also add them back into the pool. Also adds scene tokens to `tokenState`
     * @category GMOnly
     * @function
     */
    static setupScene() {
        return __awaiter(this, void 0, void 0, function* () {
            let stateObjects = canvas.scene.getFlag(MODULE_ID, 'splatState');
            log(LogLevel.INFO, 'setupScene stateObjects loaded:', stateObjects);
            // save tokens state
            for (let index = 0; index < canvas.tokens.placeables.length; index++) {
                const token = canvas.tokens.placeables[index];
                BloodNGuts.splatTokens[token.id] = new SplatToken(token);
            }
            // canvas.tokens.placeables.forEach((t) => {
            //   debugger;
            //   if (t.actor) {
            //     t = new SplatToken(t.data);
            //   }
            // });
            // const promises = canvasTokens.map((t) => BloodNGuts.createTokenHandler(canvas.scene, t));
            // await Promise.all(promises);
            // console.log('setupScene have we waited?');
            // const canvasTokens = canvas.tokens.placeables.filter((t) => t.actor);
            // const promises = canvasTokens.map((t) => BloodNGuts.createTokenHandler(canvas.scene, t));
            // await Promise.all(promises);
            // console.log('setupScene have we waited?');
            if (stateObjects) {
                log(LogLevel.INFO, 'setupScene drawSplats', canvas.scene.name);
                const extantTokens = Object.keys(BloodNGuts.splatTokens);
                stateObjects = stateObjects.filter((so) => !so.tokenId || extantTokens.includes(so.tokenId));
                // draw each missing splatsContainer and save a reference to it in the pool.
                // if the splatPoolSize has changed then we want to add only the latest
                const maxPoolSize = Math.min(game.settings.get(MODULE_ID, 'sceneSplatPoolSize'), stateObjects.length);
                for (let i = 0; i < maxPoolSize; i++) {
                    BloodNGuts.addToSplatPool(stateObjects[i], BloodNGuts.drawSplatsGetContainer(stateObjects[i]));
                    BloodNGuts.splatState.push(stateObjects[i]);
                }
            }
        });
    }
    /**
     * Wipes all splats from the current scene and empties all pools.
     * @category GMOnly
     * @function
     */
    static wipeSceneSplats() {
        log(LogLevel.INFO, 'wipeSceneSplats');
        canvas.scene.setFlag(MODULE_ID, 'splatState', null);
        globalThis.sceneSplatPool.forEach((poolObj) => {
            // don't destroy our already built masks
            if (poolObj.state.tokenId) {
                poolObj.splatsContainer.children.forEach((displayObj) => {
                    if (!displayObj.isMask)
                        displayObj.destroy();
                });
            }
            else
                poolObj.splatsContainer.destroy();
        });
        globalThis.sceneSplatPool = [];
        BloodNGuts.splatState = [];
    }
    /**
     * Handler called on all updateToken and updateActor events. Checks for movement and damage and
     * calls splat generate methods.
     * @category GMOnly
     * @function
     * @async
     * @param {scene} - reference to the current scene
     * @param {tokenData} - tokenData of updated Token/Actor
     * @param {changes} - changes
     */
    static updateTokenOrActorHandler(scene, tokenData, changes) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!scene.active || !game.user.isGM)
                return;
            log(LogLevel.INFO, 'updateTokenOrActorHandler', changes);
            const tokenId = tokenData._id || tokenData.data._id;
            const splatToken = this.splatTokens[tokenId];
            splatToken.updateChanges(changes);
        });
    }
    /**
     * Handler called when canvas has been fully loaded. Wipes state data and reloads from flags.
     * @category GMOnly
     * @function
     * @param {scene} - reference to the current scene
     * @param {tokenData} - tokenData of updated Token/Actor
     * @param {changes} - changes
     */
    static canvasReadyHandler(canvas) {
        if (!canvas.scene.active)
            return;
        log(LogLevel.INFO, 'canvasReady, active:', canvas.scene.name);
        //canvas.scene.setFlag(MODULE_ID, 'sceneSplatPool', null);
        // wipe pools to be refilled from scene flag data
        globalThis.sceneSplatPool = [];
        // need to wait on fonts loading before we can setupScene
        if (!BloodNGuts.allFontsLoaded)
            document.fonts.onloadingdone = () => {
                const allFontsPresent = document.fonts.check('1em ' + game.settings.get(MODULE_ID, 'floorSplatFont')) &&
                    document.fonts.check('1em ' + game.settings.get(MODULE_ID, 'tokenSplatFont')) &&
                    document.fonts.check('1em ' + game.settings.get(MODULE_ID, 'trailSplatFont'));
                if (!allFontsPresent)
                    return;
                log(LogLevel.DEBUG, 'canvasReady allFontsPresent');
                BloodNGuts.allFontsLoaded = true;
                BloodNGuts.setupScene();
            };
        else
            BloodNGuts.setupScene();
    }
    /**
     * Handler called when scene data updated. Draws splats from scene data flags.
     * @category GMandPC
     * @function
     * @param {scene} - reference to the current scene
     * @param {changes} - changes
     */
    static updateSceneHandler(scene, changes) {
        var _a, _b;
        if (!scene.active || !globalThis.sceneSplatPool)
            return;
        // if (BloodNGuts.fadingSplatPool.length) debugger;
        if (((_a = changes.flags[MODULE_ID]) === null || _a === void 0 ? void 0 : _a.splatState) === null) {
            if (game.user.isRole(CONST.USER_ROLES.PLAYER))
                BloodNGuts.wipeSceneSplats();
            return;
        }
        else if (!((_b = changes.flags[MODULE_ID]) === null || _b === void 0 ? void 0 : _b.splatState))
            return;
        log(LogLevel.INFO, 'updateSceneHandler');
        const extantTokens = Object.keys(BloodNGuts.splatTokens);
        const splatState = changes.flags[MODULE_ID].splatState.filter((so) => !so.tokenId || extantTokens.includes(so.tokenId));
        // todo: bug TypeError: Cannot read property 'splatState' of undefined
        const updatedStateIds = splatState.map((s) => s.id);
        log(LogLevel.DEBUG, 'updateScene updatedStateIds', updatedStateIds);
        const oldStateIds = globalThis.sceneSplatPool.map((poolObj) => poolObj.state.id);
        log(LogLevel.DEBUG, 'updateScene oldStateIds', oldStateIds);
        const removeIds = oldStateIds.filter((id) => !updatedStateIds.includes(id));
        log(LogLevel.DEBUG, 'updateScene removeIds', removeIds);
        if (removeIds) {
            globalThis.sceneSplatPool = globalThis.sceneSplatPool.filter((poolObj) => {
                if (removeIds.includes(poolObj.state.id)) {
                    // if it is a tokensplat we do not want to destroy our mask etc. we will just destroy the individual splats
                    if (poolObj.state.tokenId) {
                        poolObj.splatsContainer.children.forEach((displayObj) => {
                            if (!displayObj.isMask)
                                displayObj.destroy();
                        });
                    }
                    else
                        poolObj.splatsContainer.destroy();
                    return false;
                }
                return true;
            });
        }
        const addIds = updatedStateIds.filter((id) => !oldStateIds.includes(id));
        log(LogLevel.DEBUG, 'updateScene addIds', addIds);
        // addstateObjects are stateObjs that are not yet in the splat pool
        if (addIds) {
            const addStateObjects = splatState.filter((stateObj) => {
                if (addIds.includes(stateObj.id))
                    return stateObj;
            });
            // draw each missing splatsContainer and save a reference to it in the pool.
            addStateObjects.forEach((stateObj) => {
                BloodNGuts.addToSplatPool(stateObj, BloodNGuts.drawSplatsGetContainer(stateObj));
            });
            log(LogLevel.DEBUG, 'updateScene addStateObjects', addStateObjects);
        }
        log(LogLevel.DEBUG, 'updateScene sceneSplatPool', globalThis.sceneSplatPool);
    }
    /**
     * Handler called when token added to scene. Saves new tokens via `saveTokenState()`
     * @category GMOnly
     * @function
     * @param {scene} - reference to the current scene
     * @param {tokenData} - new Token data
     */
    static createTokenHandler(scene, tokenData) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!scene.active || !game.user.isGM)
                return;
            const data = tokenData.data || tokenData;
            log(LogLevel.INFO, 'createToken', data);
            debugger;
            tokenData = new SplatToken(data);
            // const ot = canvas.tokens.ownedTokens;
            //debugger;
            // const tokenSpriteWidth = data.width * canvas.grid.size * data.scale;
            // const tokenSpriteHeight = data.height * canvas.grid.size * data.scale;
            // const maskSprite = PIXI.Sprite.from(data.img);
            // maskSprite.width = tokenSpriteWidth;
            // maskSprite.height = tokenSpriteHeight;
            // log(LogLevel.DEBUG, 'drawSplats maskSprite: ', duplicate(maskSprite.width), duplicate(maskSprite.height));
            // const textureContainer = new PIXI.Container();
            // textureContainer.addChild(maskSprite);
            // const bwMatrix = new PIXI.filters.ColorMatrixFilter();
            // const negativeMatrix = new PIXI.filters.ColorMatrixFilter();
            // maskSprite.filters = [bwMatrix, negativeMatrix];
            // bwMatrix.brightness(0, false);
            // negativeMatrix.negative(false);
            // const renderTexture = new PIXI.RenderTexture(
            //   new PIXI.BaseRenderTexture({
            //     width: tokenSpriteWidth,
            //     height: tokenSpriteHeight,
            //     // scaleMode: PIXI.SCALE_MODES.LINEAR,
            //     // resolution: 1
            //   }),
            // );
            // const renderSprite = new PIXI.Sprite(renderTexture);
            // canvas.app.renderer.render(textureContainer, renderTexture);
            // const emptySplatsContainer = new PIXI.Container();
            // emptySplatsContainer.addChild(renderSprite);
            // emptySplatsContainer.mask = renderSprite;
            // emptySplatsContainer.pivot.set(tokenSpriteWidth / 2, tokenSpriteHeight / 2);
            // emptySplatsContainer.position.set(token.w / 2, token.h / 2);
            // emptySplatsContainer.angle = data.rotation;
            // console.log(token.children);
            // //return new Promise<void>((resolve, reject) => {
            // //we need to call draw to make sure the Token has set up Token.icon etc.
            // return token.draw().then(() => {
            //   // @ts-ignore
            //   const splatsContainerZIndex = token.children.findIndex((child) => child === token.icon) + 1;
            //   if (splatsContainerZIndex === 0) log(LogLevel.ERROR, 'drawSplats, cant find token.icon!');
            //   else token.addChildAt(emptySplatsContainer, splatsContainerZIndex);
            //   debugger;
            //   console.log(token.children);
            //   BloodNGuts.saveTokenState(token, 1, splatsContainerZIndex);
            // });
        });
    }
    /**
     * Handler called when left button bar is drawn
     * @category GMOnly
     * @function
     * @param {buttons} - reference to the buttons controller
     */
    static getSceneControlButtonsHandler(buttons) {
        log(LogLevel.INFO, 'getSceneControlButtonsHandler');
        const tileButtons = buttons.find((b) => b.name == 'tiles');
        if (tileButtons) {
            tileButtons.tools.push({
                name: 'wipe',
                title: 'Wipe all blood splats from this scene.',
                icon: 'fas fa-tint-slash',
                active: true,
                visible: true,
                onClick: BloodNGuts.wipeSceneSplats,
            });
        }
    }
    /**
     * Handler called when token is deleted. Removed tokenSplats and state for this token.
     * @category GMOnly
     * @function
     * @param {buttons} - reference to the buttons controller
     */
    static deleteTokenHandler(scene, token) {
        return __awaiter(this, void 0, void 0, function* () {
            // perhaps this is not scene agnostic
            if (!game.user.isGM)
                return;
            log(LogLevel.INFO, 'deleteTokenHandler', token);
            if (BloodNGuts.tokenState)
                delete BloodNGuts.tokenState[token._id];
        });
    }
}
// Hooks
Hooks.once('init', () => __awaiter(void 0, void 0, void 0, function* () {
    log(LogLevel.INFO, `Initializing module ${MODULE_ID}`);
    // Assign custom classes and constants here
    BloodNGuts.initialize();
    // Register custom module settings
    registerSettings();
    // Preload Handlebars templates
    yield preloadTemplates();
    // Register custom sheets (if any)
}));
Hooks.once('setup', () => {
    // Do anything after initialization but before
    // ready
    log(LogLevel.INFO, 'setup Hook');
});
Hooks.once('ready', () => {
    log(LogLevel.INFO, 'ready, inserting preload stub');
    // Insert a div that uses the font so that it preloads
    const stub = document.createElement('div');
    stub.style.cssText = "visibility:hidden; font-family: 'splatter';";
    stub.innerHTML = 'A';
    const stub2 = document.createElement('div');
    stub2.style.cssText = "visibility:hidden; font-family: 'WC Rhesus A Bta';";
    stub2.innerHTML = 'A';
    document.body.appendChild(stub);
    document.body.appendChild(stub2);
});
Hooks.on('canvasInit', (canvas) => {
    log(LogLevel.INFO, 'canvasInit', canvas.scene.name);
    if (!canvas.scene.active)
        log(LogLevel.INFO, 'canvasInit, skipping inactive scene');
});
Hooks.on('canvasReady', BloodNGuts.canvasReadyHandler);
Hooks.on('createToken', BloodNGuts.createTokenHandler);
Hooks.on('updateToken', BloodNGuts.updateTokenOrActorHandler);
Hooks.on('updateActor', (actor, changes) => {
    if (!canvas.scene.active || !game.user.isGM)
        return;
    // convert into same structure as token changes.
    if (changes.data)
        changes.actorData = { data: changes.data };
    const token = canvas.tokens.placeables.filter((t) => t.actor).find((t) => t.actor.id === actor.id);
    if (!token)
        log(LogLevel.ERROR, 'updateActor token not found!');
    else
        BloodNGuts.updateTokenOrActorHandler(canvas.scene, token.data, changes);
});
Hooks.on('deleteToken', BloodNGuts.deleteTokenHandler);
Hooks.on('updateScene', BloodNGuts.updateSceneHandler);
Hooks.on('getSceneControlButtons', BloodNGuts.getSceneControlButtonsHandler);
class SplatToken {
    constructor(token) {
        this.id = token.id;
        this.token = token;
        this.w = token.data.width * canvas.grid.size * token.data.scale;
        this.h = token.data.height * canvas.grid.size * token.data.scale;
        this.bloodColor = lookupTokenBloodColor(token.data);
        this.saveState(token.data, 1);
        this.splatsContainer = new PIXI.Container();
        const tokenSpriteWidth = token.data.width * canvas.grid.size * token.data.scale;
        const tokenSpriteHeight = token.data.height * canvas.grid.size * token.data.scale;
        const maskSprite = PIXI.Sprite.from(token.data.img);
        maskSprite.width = tokenSpriteWidth;
        maskSprite.height = tokenSpriteHeight;
        log(LogLevel.DEBUG, 'drawSplats maskSprite: ', duplicate(maskSprite.width), duplicate(maskSprite.height));
        const textureContainer = new PIXI.Container();
        textureContainer.addChild(maskSprite);
        const bwMatrix = new PIXI.filters.ColorMatrixFilter();
        const negativeMatrix = new PIXI.filters.ColorMatrixFilter();
        maskSprite.filters = [bwMatrix, negativeMatrix];
        bwMatrix.brightness(0, false);
        negativeMatrix.negative(false);
        const renderTexture = new PIXI.RenderTexture(new PIXI.BaseRenderTexture({
            width: tokenSpriteWidth,
            height: tokenSpriteHeight,
        }));
        const renderSprite = new PIXI.Sprite(renderTexture);
        canvas.app.renderer.render(textureContainer, renderTexture);
        this.splatsContainer.addChild(renderSprite);
        //this.splatsContainer.mask = renderSprite;
        this.splatsContainer.pivot.set(tokenSpriteWidth / 2, tokenSpriteHeight / 2);
        this.splatsContainer.position.set(tokenSpriteWidth / 2, tokenSpriteHeight / 2);
        this.splatsContainer.angle = token.data.rotation;
    }
    setBleeding(isBleeding) {
        if (this.isBleeding === isBleeding)
            return;
        this.isBleeding = isBleeding;
        this.token.setFlag(MODULE_ID, 'bleeding', isBleeding);
        if (isBleeding) {
            const density = game.settings.get(MODULE_ID, 'trailSplatDensity');
            this.bleedingCount = density > 0 && density < 1 ? Math.round(1 / density) : null;
        }
    }
    setSeverity(severity) {
        if (severity === 0)
            this.bleedingSeverity = 1;
        else
            this.bleedingSeverity = Math.max(this.bleedingSeverity, severity);
        this.hitSeverity = severity;
    }
    saveState(tokenData, severity) {
        this.x = tokenData.x;
        this.y = tokenData.y;
        this.hp = tokenData.actorData.data.attributes.hp.value;
        this.maxHP = tokenData.actorData.data.attributes.hp.max;
        // only save severity if it's higher. if severity is 0 reset to 1.
        this.setSeverity(severity);
    }
    updateChanges(changes) {
        var _a, _b, _c;
        if (changes.rotation === undefined &&
            changes.x === undefined &&
            changes.y === undefined &&
            ((_c = (_b = (_a = changes.actorData) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.attributes) === null || _c === void 0 ? void 0 : _c.hp) === undefined)
            return;
        // update rotation of tokenSplats
        this.updateDamage(changes);
        this.updateMovement(changes);
        this.updateBleeding(changes);
        this.bleedFloor();
        this.bleedTrail();
        this.updateRotation(changes);
        //BloodNGuts.saveTokenState(token, severity);
        // filter out null entries returned when density = 0
        // stateObjects = stateObjects.filter((s) => s);
        // promises.push(BloodNGuts.saveToSceneFlag(stateObjects));
        // await Promise.all(promises)
    }
    bleedFloor() {
        if (this.hitSeverity > 0) {
            log(LogLevel.DEBUG, 'updateTokenOrActorHandler damageScale > 0:' + this.id + ' - bleeding:true');
            BloodNGuts.splatFloor(this, splatFonts.fonts[game.settings.get(MODULE_ID, 'floorSplatFont')], game.settings.get(MODULE_ID, 'floorSplatSize'), Math.round(game.settings.get(MODULE_ID, 'floorSplatDensity')));
        }
    }
    bleedTrail() {
        const density = game.settings.get(MODULE_ID, 'trailSplatDensity');
        if (density > 0 && density < 1) {
            if (this.bleedingCount === 0) {
                BloodNGuts.splatFloor(this, splatFonts.fonts[game.settings.get(MODULE_ID, 'trailSplatFont')], game.settings.get(MODULE_ID, 'trailSplatSize'), 1);
            }
        }
        else {
            BloodNGuts.splatTrail(this, splatFonts.fonts[game.settings.get(MODULE_ID, 'trailSplatFont')], game.settings.get(MODULE_ID, 'trailSplatSize'), density);
        }
    }
    bleedToken() {
        const density = game.settings.get(MODULE_ID, 'trailSplatDensity');
        // BloodNGuts.splatToken(
        //   this,
        //   splatFonts.fonts[game.settings.get(MODULE_ID, 'tokenSplatFont')],
        //   game.settings.get(MODULE_ID, 'tokenSplatSize'),
        //   Math.round(game.settings.get(MODULE_ID, 'tokenSplatDensity')),
        // );
    }
    updateBleeding(changes) {
        if (!this.direction || !this.isBleeding)
            return;
        const density = game.settings.get(MODULE_ID, 'trailSplatDensity');
        if (!--this.bleedingCount)
            this.bleedingCount = Math.round(1 / density);
    }
    updateDamage(changes) {
        var _a;
        if (changes.actorData === undefined || ((_a = changes.actorData.data.attributes) === null || _a === void 0 ? void 0 : _a.hp) === undefined)
            return;
        this.setSeverity(this.getDamageSeverity(changes));
        if (this.hitSeverity > 1)
            this.setBleeding(true);
        else if (this.hitSeverity < 0)
            this.setBleeding(false);
        log(LogLevel.DEBUG, 'updateTokenOrActorHandler this.hitSeverity', this.hitSeverity);
    }
    updateMovement(changes) {
        if (changes.x === undefined && changes.y === undefined)
            return;
        const posX = changes.x === undefined ? this.x : changes.x;
        const posY = changes.y === undefined ? this.y : changes.y;
        const currPos = new PIXI.Point(posX, posY);
        const lastPos = new PIXI.Point(this.x, this.y);
        log(LogLevel.DEBUG, 'checkForMovement pos: l,c:', lastPos, currPos);
        this.direction = getDirectionNrml(lastPos, currPos);
    }
    updateRotation(changes) {
        if (changes.rotation === undefined)
            return;
        log(LogLevel.DEBUG, 'updateTokenOrActorHandler updating rotation', changes.rotation);
        //this.rotate(changes.rotation);
    }
    draw() {
        return __awaiter(this, void 0, void 0, function* () { });
    }
    /**
     * Get severity, a number between -1 and 2:
     * * > -1[full health or fully healed] to  0[minimal heal]
     * * > 1 + (0[minimal damage] and 0.5[all HP in one hit])* 2 [if dead]
     * * or 0 if not hit at all.
     * @category GMOnly
     * @function
     * @param {Token} token - the token to check.
     * @param {any} changes - the token.actor changes object.
     * @returns {number} - the damage severity.
     */
    getDamageSeverity(changes) {
        log(LogLevel.INFO, 'getDamageSeverity', changes.actorData);
        const currentHP = changes.actorData.data.attributes.hp.value;
        //fully healed, return -1
        if (currentHP === this.maxHP)
            return -1;
        const healthThreshold = game.settings.get(MODULE_ID, 'healthThreshold');
        const damageThreshold = game.settings.get(MODULE_ID, 'damageThreshold');
        const lastHP = this.hp;
        const fractionOfMax = currentHP / this.maxHP;
        const changeFractionOfMax = (lastHP - currentHP) / this.maxHP;
        if (currentHP && currentHP < lastHP) {
            if (fractionOfMax > healthThreshold) {
                log(LogLevel.DEBUG, 'getDamageSeverity below healthThreshold', fractionOfMax);
                return 0;
            }
            if (changeFractionOfMax < damageThreshold) {
                log(LogLevel.DEBUG, 'getDamageSeverity below damageThreshold', fractionOfMax);
                return 0;
            }
        }
        // healing
        if (changeFractionOfMax < 0) {
            //renormalise scale based on threshold.
            return changeFractionOfMax / healthThreshold;
        }
        // dead, multiply by 2.
        const deathMultiplier = currentHP === 0 ? 2 : 1;
        const severity = 1 + (changeFractionOfMax / 2) * deathMultiplier;
        log(LogLevel.DEBUG, 'getDamageSeverity severity', severity);
        return severity;
    }
}
// Token.prototype.draw = (function () {
//   const cached = Token.prototype.draw;
//   return function () {
//     const p = cached.apply(this);
//     this.splats = BloodNGuts.splatTokens[this.id].draw();
//     return p;
//   };
// })();
// Token.prototype.draw = SplatToken.draw;
