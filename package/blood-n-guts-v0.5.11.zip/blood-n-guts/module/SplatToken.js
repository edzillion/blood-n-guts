var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { log, LogLevel } from "../module/logging.js";
import { BloodNGuts } from "../blood-n-guts.js";
import { MODULE_ID } from "../constants.js";
import { lookupTokenBloodColor, getRandomGlyph, getRandomBoxMuller, alignSplatsGetOffsetAndDimensions, getDirectionNrml, getUID, } from "./helpers.js";
import * as splatFonts from "../data/splatFonts.js";
export default class SplatToken {
    constructor(token) {
        // @ts-ignore
        this.id = token.id || token.actor.data._id;
        this.token = token;
        this.spriteWidth = token.data.width * canvas.grid.size * token.data.scale;
        this.spriteHeight = token.data.height * canvas.grid.size * token.data.scale;
        this.bloodColor = lookupTokenBloodColor(token);
        this.saveState(token);
        this.bleedingSeverity = this.token.getFlag(MODULE_ID, 'bleedingSeverity');
        this.tokenSplats = this.token.getFlag(MODULE_ID, 'splats') || [];
        this.splatsContainer = new PIXI.Container();
    }
    createMask() {
        return __awaiter(this, void 0, void 0, function* () {
            // @ts-ignore
            const maskTexture = yield PIXI.Texture.fromURL(this.token.data.img);
            const maskSprite = PIXI.Sprite.from(maskTexture);
            maskSprite.width = this.spriteWidth;
            maskSprite.height = this.spriteHeight;
            const textureContainer = new PIXI.Container();
            textureContainer.addChild(maskSprite);
            const bwMatrix = new PIXI.filters.ColorMatrixFilter();
            const negativeMatrix = new PIXI.filters.ColorMatrixFilter();
            maskSprite.filters = [bwMatrix, negativeMatrix];
            bwMatrix.brightness(0, false);
            negativeMatrix.negative(false);
            const renderTexture = new PIXI.RenderTexture(new PIXI.BaseRenderTexture({
                width: this.spriteWidth,
                height: this.spriteHeight,
            }));
            const renderSprite = new PIXI.Sprite(renderTexture);
            canvas.app.renderer.render(textureContainer, renderTexture);
            this.splatsContainer.addChild(renderSprite);
            this.splatsContainer.mask = renderSprite;
            this.splatsContainer.pivot.set(this.spriteWidth / 2, this.spriteHeight / 2);
            this.splatsContainer.position.set((this.token.data.width * canvas.grid.size) / 2, (this.token.data.height * canvas.grid.size) / 2);
            this.splatsContainer.angle = this.token.data.rotation;
        });
    }
    updateSplats(updatedSplats) {
        this.tokenSplats = updatedSplats || [];
        this.draw();
    }
    updateChanges(changes) {
        var _a, _b, _c;
        return __awaiter(this, void 0, void 0, function* () {
            if (changes.rotation === undefined &&
                changes.x === undefined &&
                changes.y === undefined &&
                ((_c = (_b = (_a = changes.actorData) === null || _a === void 0 ? void 0 : _a.data) === null || _b === void 0 ? void 0 : _b.attributes) === null || _c === void 0 ? void 0 : _c.hp) === undefined)
                return;
            this.updateDamage(changes);
            this.updateMovement(changes);
            this.updateBleeding();
            if (this.hitSeverity > 0) {
                this.bleedFloor();
                this.bleedToken();
            }
            else if (this.hitSeverity < 0) {
                this.healToken();
            }
            if (this.direction && this.bleedingSeverity)
                this.bleedTrail();
            this.updateRotation(changes);
            this.saveState(this.token);
            const updateObj = {
                flags: { [MODULE_ID]: { bleedingSeverity: this.bleedingSeverity, splats: duplicate(this.tokenSplats) } },
            };
            yield this.token.update(updateObj);
        });
    }
    updateDamage(changes) {
        var _a;
        if (changes.actorData === undefined || ((_a = changes.actorData.data.attributes) === null || _a === void 0 ? void 0 : _a.hp) === undefined)
            return;
        this.setSeverity(this.getDamageSeverity(changes));
    }
    updateMovement(changes) {
        if (changes.x === undefined && changes.y === undefined)
            return;
        const posX = changes.x === undefined ? this.x : changes.x;
        const posY = changes.y === undefined ? this.y : changes.y;
        const currPos = new PIXI.Point(posX, posY);
        const lastPos = new PIXI.Point(this.x, this.y);
        log(LogLevel.DEBUG, 'checkForMovement pos: l,c:', lastPos, currPos);
        this.direction = getDirectionNrml(lastPos, currPos);
    }
    updateBleeding() {
        if (!this.direction || !this.bleedingSeverity)
            return;
        const density = game.settings.get(MODULE_ID, 'trailSplatDensity');
        if (!--this.bleedingCount)
            this.bleedingCount = Math.round(1 / density);
    }
    updateRotation(changes) {
        if (changes.rotation === undefined)
            return;
        log(LogLevel.DEBUG, 'updateTokenOrActorHandler updating rotation', changes.rotation);
        this.splatsContainer.angle = changes.rotation;
    }
    bleedFloor() {
        const density = game.settings.get(MODULE_ID, 'floorSplatDensity');
        if (!density)
            return;
        log(LogLevel.DEBUG, 'updateTokenOrActorHandler damageScale > 0:' + this.id + ' - bleeding:true');
        BloodNGuts.generateFloorSplats(this, splatFonts.fonts[game.settings.get(MODULE_ID, 'floorSplatFont')], game.settings.get(MODULE_ID, 'floorSplatSize'), Math.round(density));
    }
    bleedTrail() {
        const density = game.settings.get(MODULE_ID, 'trailSplatDensity');
        if (!density)
            return;
        if (density > 0 && density < 1) {
            if (this.bleedingCount === 0) {
                BloodNGuts.generateFloorSplats(this, splatFonts.fonts[game.settings.get(MODULE_ID, 'trailSplatFont')], game.settings.get(MODULE_ID, 'trailSplatSize'), 1);
            }
        }
        else {
            BloodNGuts.generateTrailSplats(this, splatFonts.fonts[game.settings.get(MODULE_ID, 'trailSplatFont')], game.settings.get(MODULE_ID, 'trailSplatSize'), density);
        }
    }
    bleedToken() {
        return __awaiter(this, void 0, void 0, function* () {
            const splatStateObj = {};
            const density = game.settings.get(MODULE_ID, 'tokenSplatDensity');
            if (density === 0)
                return;
            const font = splatFonts.fonts[game.settings.get(MODULE_ID, 'tokenSplatFont')];
            // scale the splats based on token size and severity
            const fontSize = Math.round(game.settings.get(MODULE_ID, 'trailSplatSize') *
                ((this.spriteWidth + this.spriteHeight) / canvas.grid.size / 2) *
                this.hitSeverity);
            log(LogLevel.DEBUG, 'bleedToken fontSize', fontSize);
            splatStateObj.styleData = {
                fontFamily: font.name,
                fontSize: fontSize,
                fill: this.bloodColor,
                align: 'center',
            };
            const style = new PIXI.TextStyle(splatStateObj.styleData);
            // amount of splats is based on density and severity
            const amount = Math.round(density * this.hitSeverity);
            if (amount === 0)
                return;
            // get a random glyph and then get a random (x,y) spread away from the token.
            const glyphArray = Array.from({ length: amount }, () => getRandomGlyph(font));
            const pixelSpreadX = this.spriteWidth * game.settings.get(MODULE_ID, 'splatSpread');
            const pixelSpreadY = this.spriteHeight * game.settings.get(MODULE_ID, 'splatSpread');
            log(LogLevel.DEBUG, 'bleedToken amount', amount);
            log(LogLevel.DEBUG, 'bleedToken pixelSpread', pixelSpreadX, pixelSpreadY);
            // create our splats for later drawing.
            splatStateObj.splats = glyphArray.map((glyph) => {
                const tm = PIXI.TextMetrics.measureText(glyph, style);
                const randX = getRandomBoxMuller() * pixelSpreadX - pixelSpreadX / 2;
                const randY = getRandomBoxMuller() * pixelSpreadY - pixelSpreadY / 2;
                return {
                    x: Math.round(randX - tm.width / 2),
                    y: Math.round(randY - tm.height / 2),
                    width: tm.width,
                    height: tm.height,
                    glyph: glyph,
                };
            });
            const { offset } = alignSplatsGetOffsetAndDimensions(splatStateObj.splats);
            splatStateObj.offset = offset;
            splatStateObj.splats.forEach((s) => {
                s.x += offset.x + this.spriteHeight / 2;
                s.y += offset.y + this.spriteWidth / 2;
            });
            splatStateObj.id = getUID();
            splatStateObj.tokenId = this.id;
            this.tokenSplats.push(splatStateObj);
            BloodNGuts.scenePool.push({ state: splatStateObj, splatsContainer: this.splatsContainer });
            //await this.token.setFlag(MODULE_ID, 'splats', this.tokenSplats);
        });
    }
    healToken() {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.tokenSplats)
                return;
            // make positive for sanity purposes
            let tempSeverity = this.hitSeverity * -1;
            // deal with scale/healthThreshold > 1. We can only heal to 100%
            if (tempSeverity > 1)
                tempSeverity = 1;
            log(LogLevel.DEBUG, 'healToken allTokensSplats:');
            let removeAmount = Math.ceil(this.tokenSplats.length * tempSeverity);
            log(LogLevel.DEBUG, 'healToken removeAmount:', removeAmount);
            while (removeAmount-- > 0) {
                const state = this.tokenSplats.shift();
                BloodNGuts.scenePool = BloodNGuts.scenePool.filter((poolObj) => poolObj.state.id != state.id);
            }
            //await this.token.setFlag(MODULE_ID, 'splats', this.tokenSplats);
        });
    }
    saveState(token) {
        this.x = token.x;
        this.y = token.y;
        this.hp = token.actor.data.data.attributes.hp.value;
        this.maxHP = token.actor.data.data.attributes.hp.max;
        // reset hit severity and direction for next round.
        this.hitSeverity = null;
        this.direction = null;
    }
    setSeverity(severity) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            this.hitSeverity = severity;
            if (this.hitSeverity > ((_a = this.bleedingSeverity) !== null && _a !== void 0 ? _a : 0) + 1) {
                this.bleedingSeverity = this.hitSeverity;
                //await this.token.setFlag(MODULE_ID, 'bleedingSeverity', severity);
            }
            else if (this.hitSeverity < 0) {
                this.bleedingSeverity = null;
                //await this.token.setFlag(MODULE_ID, 'bleedingSeverity', null);
            }
        });
    }
    /**
     * Get severity, a number between -1 and 2:
     * * > -1[full health or fully healed] to  0[minimal heal]
     * * > 1 + (0[minimal damage] and 0.5[all HP in one hit])* 2 [if dead]
     * * or 0 if not hit at all.
     * @category GMOnly
     * @function
     * @param {Token} token - the token to check.
     * @param {any} changes - the token.actor changes object.
     * @returns {number} - the damage severity.
     */
    getDamageSeverity(changes) {
        log(LogLevel.INFO, 'getDamageSeverity', changes.actorData);
        const currentHP = changes.actorData.data.attributes.hp.value;
        //fully healed, return -1
        if (currentHP === this.maxHP)
            return -1;
        const healthThreshold = game.settings.get(MODULE_ID, 'healthThreshold');
        const damageThreshold = game.settings.get(MODULE_ID, 'damageThreshold');
        const lastHP = this.hp;
        const fractionOfMax = currentHP / this.maxHP;
        const changeFractionOfMax = (lastHP - currentHP) / this.maxHP;
        if (currentHP && currentHP < lastHP) {
            if (fractionOfMax > healthThreshold) {
                log(LogLevel.DEBUG, 'getDamageSeverity below healthThreshold', fractionOfMax);
                return 0;
            }
            if (changeFractionOfMax < damageThreshold) {
                log(LogLevel.DEBUG, 'getDamageSeverity below damageThreshold', fractionOfMax);
                return 0;
            }
        }
        // healing
        if (changeFractionOfMax < 0) {
            //renormalise scale based on threshold.
            return changeFractionOfMax / healthThreshold;
        }
        // dead, multiply by 2.
        const deathMultiplier = currentHP === 0 ? 2 : 1;
        const severity = 1 + (changeFractionOfMax / 2) * deathMultiplier;
        log(LogLevel.DEBUG, 'getDamageSeverity severity', severity);
        return severity;
    }
    wipe() {
        let counter = 0;
        // delete everything except the sprite mask
        while (this.splatsContainer.children.length > 1) {
            const displayObj = this.splatsContainer.children[counter];
            if (!displayObj.isMask)
                displayObj.destroy();
            else
                counter++;
        }
    }
    wipeAll() {
        this.wipe();
        this.tokenSplats = [];
        this.token.setFlag(MODULE_ID, 'splats', null);
    }
    removeState(id) {
        this.tokenSplats = this.tokenSplats.filter((stateObj) => stateObj.id !== id);
    }
    draw() {
        log(LogLevel.DEBUG, 'drawSplats: splatStateObj.tokenId');
        this.wipe();
        // @ts-ignore
        if (!this.tokenSplats || this.tokenSplats === 'wipe')
            return;
        BloodNGuts.allFontsReady.then(() => {
            this.tokenSplats.forEach((splatState) => {
                splatState.splats.forEach((splat) => {
                    const text = new PIXI.Text(splat.glyph, splatState.styleData);
                    text.x = splat.x;
                    text.y = splat.y;
                    this.splatsContainer.addChild(text);
                });
            });
        });
    }
}
