export const MODULE_ID = 'blood-n-guts';
